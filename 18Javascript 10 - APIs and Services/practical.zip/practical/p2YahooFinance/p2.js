var request = new XMLHttpRequest();

request.onreadystatechange = function() {//Call this function when the state changes.
    if (request.readyState == 4) {
        if (request.status == 200 || request.status == 0) {
            var stockData = JSON.parse(request.responseText);
          	//console.log(stockData);
          		document.getElementById("output").innerHTML=stockData.query.results.quote.LastTradePriceOnly;
          
        }
    }
};

function go() {
var url = ""; //insert here the relevant URL to retrieve a stock ticket as input by the user from Yahoo finance API
console.log(url);
request.open("GET", url, true);
request.send();
}

document.getElementById("bu").addEventListener("click", go);
